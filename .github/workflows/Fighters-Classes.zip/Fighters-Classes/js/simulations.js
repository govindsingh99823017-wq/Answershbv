document.addEventListener('DOMContentLoaded', () => {
  const sims = [
    { url: "https://phet.colorado.edu/sims/html/my-solar-system/latest/my-solar-system_en.html", title: "🌌 My Solar System" },
    { url: "https://phet.colorado.edu/sims/html/quantum-coin-toss/latest/quantum-coin-toss_en.html", title: "🎲 Quantum Coin Toss" },
    { url: "https://phet.colorado.edu/sims/html/quantum-measurement/latest/quantum-measurement_en.html", title: "📏 Quantum Measurement" },
    { url: "https://phet.colorado.edu/sims/html/models-of-the-hydrogen-atom/latest/models-of-the-hydrogen-atom_en.html", title: "⚛️ Hydrogen Atom Models" },
    { url: "https://phet.colorado.edu/sims/html/buoyancy-basics/latest/buoyancy-basics_en.html", title: "💧 Buoyancy Basics" },
    { url: "https://phet.colorado.edu/sims/html/buoyancy/latest/buoyancy_en.html", title: "⛵ Buoyancy" },
    { url: "https://phet.colorado.edu/sims/html/generator/latest/generator_en.html", title: "⚡ Generator" },
    { url: "https://phet.colorado.edu/sims/html/magnets-and-electromagnets/latest/magnets-and-electromagnets_en.html", title: "🧲 Magnets & Electromagnets" },
    { url: "https://phet.colorado.edu/sims/html/magnet-and-compass/latest/magnet-and-compass_en.html", title: "🧭 Magnet & Compass" },
    { url: "https://phet.colorado.edu/sims/html/faradays-electromagnetic-lab/latest/faradays-electromagnetic-lab_en.html", title: "🔁 Faraday's Electromagnetic Lab" },
    { url: "https://phet.colorado.edu/sims/html/projectile-data-lab/latest/projectile-data-lab_en.html", title: "🎯 Projectile Data Lab" },
    { url: "https://phet.colorado.edu/sims/html/build-a-nucleus/latest/build-a-nucleus_en.html", title: "🔬 Build a Nucleus" },
    { url: "https://phet.colorado.edu/sims/html/sound-waves/latest/sound-waves_en.html", title: "🎵 Sound Waves" },
    { url: "https://phet.colorado.edu/sims/html/keplers-laws/latest/keplers-laws_en.html", title: "🪐 Kepler's Laws" },
    { url: "https://phet.colorado.edu/sims/html/calculus-grapher/latest/calculus-grapher_en.html", title: "📈 Calculus Grapher" },
    { url: "https://phet.colorado.edu/sims/html/geometric-optics-basics/latest/geometric-optics-basics_en.html", title: "🔍 Geometric Optics Basics" },
    { url: "https://phet.colorado.edu/sims/html/geometric-optics/latest/geometric-optics_en.html", title: "🔎 Geometric Optics" },
    { url: "https://phet.colorado.edu/sims/html/density/latest/density_en.html", title: "⚖️ Density" },
    { url: "https://phet.colorado.edu/sims/html/circuit-construction-kit-ac/latest/circuit-construction-kit-ac_en.html", title: "💡 Circuit Construction Kit (AC)" },
    { url: "https://phet.colorado.edu/sims/html/circuit-construction-kit-ac-virtual-lab/latest/circuit-construction-kit-ac-virtual-lab_en.html", title: "🛠️ AC Virtual Lab" },
    { url: "https://phet.colorado.edu/sims/html/normal-modes/latest/normal-modes_en.html", title: "🎸 Normal Modes" },
    { url: "https://phet.colorado.edu/sims/html/fourier-making-waves/latest/fourier-making-waves_en.html", title: "📊 Fourier: Making Waves" },
    { url: "https://phet.colorado.edu/sims/html/collision-lab/latest/collision-lab_en.html", title: "💥 Collision Lab" },
    { url: "https://phet.colorado.edu/sims/html/energy-skate-park/latest/energy-skate-park_en.html", title: "🛹 Energy Skate Park" },
    { url: "https://phet.colorado.edu/sims/html/vector-addition/latest/vector-addition_en.html", title: "➕ Vector Addition" },
    { url: "https://phet.colorado.edu/sims/html/curve-fitting/latest/curve-fitting_en.html", title: "📉 Curve Fitting" },
    { url: "https://phet.colorado.edu/sims/html/gravity-force-lab-basics/latest/gravity-force-lab-basics_en.html", title: "🌍 Gravity Force Lab Basics" },
    { url: "https://phet.colorado.edu/sims/html/waves-intro/latest/waves-intro_en.html", title: "🌊 Waves Intro" },
    { url: "https://phet.colorado.edu/sims/html/diffusion/latest/diffusion_en.html", title: "🧪 Diffusion" },
    { url: "https://phet.colorado.edu/sims/html/gases-intro/latest/gases-intro_en.html", title: "💨 Gases Intro" },
    { url: "https://phet.colorado.edu/sims/html/gas-properties/latest/gas-properties_en.html", title: "🧯 Gas Properties" },
    { url: "https://phet.colorado.edu/sims/html/blackbody-spectrum/latest/blackbody-spectrum_en.html", title: "🔥 Blackbody Spectrum" },
    { url: "https://phet.colorado.edu/sims/html/masses-and-springs-basics/latest/masses-and-springs-basics_en.html", title: "⚙️ Masses & Springs Basics" },
    { url: "https://phet.colorado.edu/sims/html/energy-forms-and-changes/latest/energy-forms-and-changes_en.html", title: "🔋 Energy Forms & Changes" },
    { url: "https://phet.colorado.edu/sims/html/wave-interference/latest/wave-interference_en.html", title: "🌊 Wave Interference" },
    { url: "https://phet.colorado.edu/sims/html/coulombs-law/latest/coulombs-law_en.html", title: "⚡ Coulomb's Law" },
    { url: "https://phet.colorado.edu/sims/html/masses-and-springs/latest/masses-and-springs_en.html", title: "🏋️ Masses & Springs" },
    { url: "https://phet.colorado.edu/sims/html/capacitor-lab-basics/latest/capacitor-lab-basics_en.html", title: "🔌 Capacitor Lab Basics" },
    { url: "https://phet.colorado.edu/sims/html/circuit-construction-kit-dc-virtual-lab/latest/circuit-construction-kit-dc-virtual-lab_en.html", title: "🔧 DC Virtual Lab" },
    { url: "https://phet.colorado.edu/sims/html/circuit-construction-kit-dc/latest/circuit-construction-kit-dc_en.html", title: "🔋 Circuit Construction Kit (DC)" },
    { url: "https://phet.colorado.edu/sims/html/pendulum-lab/latest/pendulum-lab_en.html", title: "⏱️ Pendulum Lab" },
    { url: "https://phet.colorado.edu/sims/html/projectile-motion/latest/projectile-motion_en.html", title: "🏹 Projectile Motion" },
    { url: "https://phet.colorado.edu/sims/html/states-of-matter-basics/latest/states-of-matter-basics_en.html", title: "❄️ States of Matter Basics" },
    { url: "https://phet.colorado.edu/sims/html/states-of-matter/latest/states-of-matter_en.html", title: "🧊 States of Matter" },
    { url: "https://phet.colorado.edu/sims/html/gravity-and-orbits/latest/gravity-and-orbits_en.html", title: "🛰️ Gravity and Orbits" },
    { url: "https://phet.colorado.edu/sims/html/plinko-probability/latest/plinko-probability_en.html", title: "🎯 Plinko Probability" },
    { url: "https://phet.colorado.edu/sims/html/atomic-interactions/latest/atomic-interactions_en.html", title: "⚛️ Atomic Interactions" },
    { url: "https://phet.colorado.edu/sims/html/charges-and-fields/latest/charges-and-fields_en.html", title: "🔋 Charges and Fields" },
    { url: "https://phet.colorado.edu/sims/html/rutherford-scattering/latest/rutherford-scattering_en.html", title: "💥 Rutherford Scattering" },
    { url: "https://phet.colorado.edu/sims/html/bending-light/latest/bending-light_en.html", title: "💡 Bending Light" },
    { url: "https://phet.colorado.edu/sims/html/hookes-law/latest/hookes-law_en.html", title: "📏 Hooke's Law" },
    { url: "https://phet.colorado.edu/sims/html/molecules-and-light/latest/molecules-and-light_en.html", title: "🔦 Molecules and Light" },
    { url: "https://phet.colorado.edu/sims/html/energy-skate-park-basics/latest/energy-skate-park-basics_en.html", title: "🛹 Energy Skate Park Basics" },
    { url: "https://phet.colorado.edu/sims/html/faradays-law/latest/faradays-law_en.html", title: "🧲 Faraday's Law" },
    { url: "https://phet.colorado.edu/sims/html/wave-on-a-string/latest/wave-on-a-string_en.html", title: "🧵 Wave on a String" },
    { url: "https://phet.colorado.edu/sims/html/color-vision/latest/color-vision_en.html", title: "🌈 Color Vision" },
    { url: "https://phet.colorado.edu/sims/html/balancing-act/latest/balancing-act_en.html", title: "⚖️ Balancing Act" },
    { url: "https://phet.colorado.edu/sims/html/under-pressure/latest/under-pressure_en.html", title: "💧 Under Pressure" },
    { url: "https://phet.colorado.edu/sims/html/friction/latest/friction_en.html", title: "🔧 Friction" },
    { url: "https://phet.colorado.edu/sims/html/forces-and-motion-basics/latest/forces-and-motion-basics_en.html", title: "🏎️ Forces and Motion Basics" },
    { url: "https://phet.colorado.edu/sims/html/john-travoltage/latest/john-travoltage_en.html", title: "⚡ John Travoltage" },
    { url: "https://phet.colorado.edu/sims/html/gravity-force-lab/latest/gravity-force-lab_en.html", title: "🌎 Gravity Force Lab" },
    { url: "https://phet.colorado.edu/sims/html/balloons-and-static-electricity/latest/balloons-and-static-electricity_en.html", title: "🎈 Balloons & Static Electricity" },
    { url: "https://phet.colorado.edu/sims/html/ohms-law/latest/ohms-law_en.html", title: "🔌 Ohm's Law" },
    { url: "https://phet.colorado.edu/sims/html/resistance-in-a-wire/latest/resistance-in-a-wire_en.html", title: "🔋 Resistance in a Wire" },
    { url: "https://phet.colorado.edu/sims/html/build-an-atom/latest/build-an-atom_en.html", title: "🧬 Build an Atom" }
  ];

  const grid = document.getElementById('simulationsGrid');
  const search = document.getElementById('simSearch');
  let allCards = [];

  sims.forEach(s => {
    const card = document.createElement('div');
    card.className = 'sim-card';
    card.setAttribute('data-title', s.title.toLowerCase());
    card.innerHTML = `<iframe src="${s.url}" allowfullscreen loading="lazy"></iframe><div class="sim-title">${s.title}</div>`;
    grid.appendChild(card);
    allCards.push(card);
  });

  search.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase().trim();
    allCards.forEach(c => c.style.display = (q === '' || c.dataset.title.includes(q)) ? 'flex' : 'none');
  });
});