document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('booksContainer');
  if (!container) return;
  const adminLoggedIn = sessionStorage.getItem('fighterAdmin') === 'true';

  db.collection("books").orderBy("timestamp", "desc").onSnapshot(snapshot => {
    container.innerHTML = "";
    if (snapshot.empty) {
      container.innerHTML = '<p style="text-align:center; grid-column:1/-1;">No books yet.</p>';
      return;
    }
    snapshot.forEach(doc => {
      const data = doc.data();
      const card = document.createElement('div');
      card.className = 'book-card';
      card.innerHTML = `<h3><i class="fas fa-book"></i> ${escapeHtml(data.title)}</h3>
        <p>${escapeHtml(data.description || "")}</p>
        <a href="${data.link}" target="_blank" class="download-btn">📥 Download / View</a>
        ${adminLoggedIn ? `<button class="delete-btn admin-btn" data-id="${doc.id}" data-collection="books">Delete</button>` : ""}`;
      container.appendChild(card);
    });
    if (adminLoggedIn) attachDeleteEvents();
  });

  function attachDeleteEvents() {
    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.onclick = () => {
        if (confirm("Delete?")) {
          db.collection('books').doc(btn.dataset.id).delete();
        }
      };
    });
  }

  function escapeHtml(str) {
    if (!str) return "";
    return str.replace(/[&<>]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[m]);
  }
});