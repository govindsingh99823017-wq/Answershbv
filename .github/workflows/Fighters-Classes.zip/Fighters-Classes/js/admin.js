function setAdminLogin(status) {
  if (status) sessionStorage.setItem('fighterAdmin', 'true');
  else sessionStorage.removeItem('fighterAdmin');
}

function isAdminLoggedIn() {
  return sessionStorage.getItem('fighterAdmin') === 'true';
}

function renderAdminPanel() {
  const panelDiv = document.getElementById('adminPanel');
  if (!panelDiv) return;

  if (!isAdminLoggedIn()) {
    panelDiv.innerHTML = `
      <div class="admin-login" style="max-width:400px; margin:auto;">
        <h3>Admin Login</h3>
        <input type="password" id="adminPassword" placeholder="Enter Password" class="admin-input">
        <button id="loginBtn" class="admin-btn">Login</button>
        <p style="color:red; margin-top:10px; display:none;" id="loginError">Incorrect password</p>
      </div>`;
    document.getElementById('loginBtn').onclick = () => {
      if (document.getElementById('adminPassword').value === 'Govphy7541') {
        setAdminLogin(true);
        renderAdminPanel();
      } else {
        document.getElementById('loginError').style.display = 'block';
      }
    };
  } else {
    panelDiv.innerHTML = `
      <div class="admin-dashboard">
        <h3>📚 Add New Book</h3>
        <input type="text" id="bookTitle" placeholder="Title" class="admin-input">
        <textarea id="bookDesc" placeholder="Description" class="admin-input" rows="2"></textarea>
        <input type="url" id="bookLink" placeholder="Link" class="admin-input">
        <button id="addBookBtn" class="admin-btn">Add Book</button>
        
        <h3>🖼️ Add New Photo</h3>
        <input type="url" id="photoUrl" placeholder="Image URL" class="admin-input">
        <input type="text" id="photoCaption" placeholder="Caption" class="admin-input">
        <button id="addPhotoBtn" class="admin-btn">Add Photo</button>
        
        <button id="logoutAdmin" class="admin-btn delete-btn">Logout</button>
      </div>`;
    document.getElementById('addBookBtn').onclick = async () => {
      const title = document.getElementById('bookTitle').value.trim();
      const link = document.getElementById('bookLink').value.trim();
      if (!title || !link) { alert("Title and link required"); return; }
      await db.collection('books').add({
        title, description: document.getElementById('bookDesc').value.trim(),
        link, timestamp: firebase.firestore.FieldValue.serverTimestamp()
      });
      alert('Book added!');
    };
    document.getElementById('addPhotoBtn').onclick = async () => {
      const url = document.getElementById('photoUrl').value.trim();
      const caption = document.getElementById('photoCaption').value.trim();
      if (!url) { alert("URL required"); return; }
      await db.collection('gallery').add({
        imageUrl: url, caption: caption || 'Photo',
        timestamp: firebase.firestore.FieldValue.serverTimestamp()
      });
      alert('Photo added!');
    };
    document.getElementById('logoutAdmin').onclick = () => {
      setAdminLogin(false);
      renderAdminPanel();
    };
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (typeof db !== 'undefined') renderAdminPanel();
});