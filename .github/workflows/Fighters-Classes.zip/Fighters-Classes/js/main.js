let regCount = localStorage.getItem("fighterRegCount");
if (!regCount) regCount = 0;
else regCount = parseInt(regCount);
document.getElementById("regCount").innerText = regCount;

const form = document.getElementById("studentForm");
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = document.getElementById("studentName").value.trim();
  const father = document.getElementById("fatherName").value.trim();
  const mobile = document.getElementById("mobile").value.trim();
  const className = document.getElementById("classText").value.trim();
  const school = document.getElementById("school").value.trim();
  const address = document.getElementById("address").value.trim();

  if (!name || !father || !mobile || !className) {
    alert("❌ Please fill all required fields");
    return;
  }
  if (!/^\d{10}$/.test(mobile)) {
    alert("📱 Please enter a valid 10-digit mobile number.");
    return;
  }

  const emailBody = `🎓 New Registration at Fighter's Classes!\n\nStudent Name: ${name}\nFather's Name: ${father}\nMobile: ${mobile}\nClass: ${className}\nSchool: ${school || 'Not provided'}\nAddress: ${address || 'Not provided'}\nRegistered at: ${new Date().toLocaleString()}\nTotal registrations so far: ${regCount + 1}`;

  try {
    const response = await fetch("https://formsubmit.co/ajax/govindsingh99823017@gmail.com", {
      method: "POST",
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: name,
        message: emailBody,
        _subject: `🔥 New Registration: ${name} (${mobile})`,
        _template: "table",
        _captcha: "false"
      })
    });

    if (response.ok) {
      regCount++;
      localStorage.setItem("fighterRegCount", regCount);
      document.getElementById("regCount").innerText = regCount;
      alert(`✅ Registration Successful, ${name}!\n\nGovind Sir will contact you on ${mobile} soon.`);
      form.reset();
    } else {
      alert("⚠️ Email could not be sent but your registration is saved locally.");
    }
  } catch (error) {
    console.error("Error:", error);
    alert("⚠️ Network error. Registration failed.");
  }
});

const facts = [
  "⚛️ A rainbow is actually a full circle – we only see half due to the horizon!",
  "⚡ Lightning is 5 times hotter than the surface of the sun.",
  "🌌 A teaspoon of neutron star material would weigh 6 billion tons.",
  "📡 The double-slit experiment proves that electrons act as both particles and waves.",
  "🧲 Magnetism is a relativistic effect of electricity – thanks to Einstein!",
  "🔭 The Andromeda Galaxy is approaching the Milky Way at 110 km/s.",
  "🎈 A helium balloon rises because it's less dense than air – Archimedes' principle.",
  "🎸 The speed of sound (Mach 1) is 1,235 km/h at sea level.",
  "💡 Quantum entanglement: particles can instantly affect each other across the universe.",
  "🌍 Earth's core is as hot as the surface of the Sun (about 5500°C).",
  "📸 The first photograph of a black hole was captured in 2019.",
  "🧪 Schrödinger's cat thought experiment explains quantum superposition.",
  "🌀 The Coriolis effect is too weak to affect your kitchen sink!",
  "⚙️ Levers and pulleys – mechanical advantage discovered by Archimedes."
];

function showFact() {
  const i = Math.floor(Math.random() * facts.length);
  document.getElementById('factBox').innerHTML = `<i class="fas fa-lightbulb"></i> ✨ Physics Spark: ${facts[i]}`;
}

showFact();
setInterval(showFact, 15000);

document.querySelectorAll('.nav-links a, .hero-btn').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const hash = this.getAttribute('href');
    if (hash && hash !== '#' && hash.startsWith('#')) {
      e.preventDefault();
      const target = document.querySelector(hash);
      if (target) target.scrollIntoView({ behavior: 'smooth' });
    }
  });
});