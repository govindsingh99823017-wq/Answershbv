document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('galleryContainer');
  if (!container) return;
  const adminLoggedIn = sessionStorage.getItem('fighterAdmin') === 'true';

  db.collection("gallery").orderBy("timestamp", "desc").onSnapshot(snapshot => {
    // Remove previously added Firestore items (class firestore-item)
    container.querySelectorAll('.firestore-item').forEach(el => el.remove());

    snapshot.forEach(doc => {
      const data = doc.data();
      const card = document.createElement('div');
      card.className = 'gallery-card firestore-item';
      card.innerHTML = `<img src="${data.imageUrl}" class="gallery-img" onerror="this.src='https://placehold.co/400x200?text=No+Image'" loading="lazy">
        <h3>${escapeHtml(data.caption || "Photo")}</h3>
        ${adminLoggedIn ? `<button class="delete-btn admin-btn" data-id="${doc.id}" data-collection="gallery">Delete</button>` : ""}`;
      container.appendChild(card);
    });

    if (adminLoggedIn) attachDeleteEvents();
  });

  function attachDeleteEvents() {
    document.querySelectorAll('#galleryContainer .delete-btn').forEach(btn => {
      btn.onclick = () => {
        if (confirm("Delete this photo?")) {
          db.collection('gallery').doc(btn.dataset.id).delete();
        }
      };
    });
  }

  function escapeHtml(str) {
    if (!str) return "";
    return str.replace(/[&<>]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[m]);
  }
});